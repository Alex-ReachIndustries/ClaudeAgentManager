---
name: Meeting Transcription Pipeline
description: Local audio capture + whisperX transcription pipeline in MeetingNotes workspace for automated meeting notes with speaker diarization and PDF generation
type: project
---

Building a local meeting transcription pipeline in C:\Users\kuron\MeetingNotes.

**Why:** User wants to just say "start meeting", have audio captured, drop in screenshots during the meeting, say "meeting complete", and get a polished PDF of meeting notes — no manual typing required.

**How to apply:** When the user says "start meeting" in this workspace, kick off the pipeline (capture.py → transcribe.py → generate notes → PrintingPress PDF). Images dropped during the meeting should be matched to transcript content semantically, not just by timestamp. The pipeline uses VoiceMeeter Banana + FFmpeg for audio capture, whisperX for STT + speaker diarization, and PrintingPress for PDF generation.

Key files: capture.py, transcribe.py, pipeline.py, config.yaml. Venv at .venv/. HF token in .env.
