---
name: Always send full projects and todos in every agent manager update
description: Every POST to agent manager must include the complete current state of all projects and todos — not just when they change
type: feedback
---

Every agent manager update must include `projects` and `todos` arrays with the full current state. The dashboard renders these panels from the latest update's metadata — if you omit them, the dashboard goes stale and shows outdated or empty project/todo panels.

**Why:** User noticed projects and todos were disappearing from the dashboard because updates were only including them when they changed, leaving subsequent updates without the data.

**How to apply:** On every `/agent-checkin` call, read all `.claude/projects/*.md` and `.claude/todos/*.md` files, build the full arrays, and include them in the POST body. If there are no active projects or todos, send empty arrays. Never omit these fields.
