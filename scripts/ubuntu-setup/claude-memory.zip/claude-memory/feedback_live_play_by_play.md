---
name: Post live play-by-play updates before each step
description: Before starting each implementation step, post a brief text update to agent manager saying what you're about to do
type: feedback
---

Before starting each step, post a brief `text` type update to the agent manager saying what you're about to do (e.g., "Reading db.ts", "Editing updateAgent function", "Running docker build"). This gives the dashboard a live play-by-play.

**Why:** The user watches the dashboard for real-time progress. Without pre-step updates, the dashboard only shows state changes after work is done, leaving gaps where nothing seems to be happening.

**How to apply:** At the start of every discrete action (reading a file, editing code, running a build, running tests), post a quick `/agent-checkin` with type `text` before doing the action. Keep it brief — one sentence.
