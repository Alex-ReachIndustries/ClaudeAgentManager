---
name: Agent manager updates should sound natural
description: Write agent manager updates conversationally, like a colleague giving a status update — not as terse machine log entries
type: feedback
---

Agent manager updates (both `summary` and `content` fields) should read like natural communication, not structured log lines. The dashboard is read by a human.

**Why:** User pointed out that updates like "File attachments implemented: upload, store, serve, UI attach button" don't reflect how Claude actually communicates in a session. They want the dashboard to feel like reading a colleague's status updates.

**How to apply:** Write `content` as you'd naturally explain what you just did to the user. Keep `summary` short but still human-readable. Avoid colon-separated lists, abbreviations, or telegraphic style.

Bad: `"Mobile layout reordered: Messages → Projects/Todos → Timeline"`
Good: `"Reordered the mobile layout so messages appear at the top when you're on your phone, with projects and todos below, and the timeline last."`
