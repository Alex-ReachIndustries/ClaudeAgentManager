---
name: Calculate progress mechanically from todo counts
description: Progress percentage must be Math.round((completed todos / total todos) * 100) — never estimate
type: feedback
---

Always calculate the `progress` field mechanically: `Math.round((completed todos / total todos) * 100)`. Never estimate or approximate.

**Why:** Estimated progress is unreliable and inconsistent. Mechanical calculation from actual todo state ensures accuracy and predictability.

**How to apply:** Count completed and total todos from TodoWrite state, compute the ratio, round to nearest integer, and use that as the progress value in every agent-checkin POST.
