---
name: Image Matching Intelligence
description: When placing images in meeting notes, match by content relevance not just timestamp
type: feedback
---

Match images to meeting content semantically, not just by timestamp.

**Why:** User explicitly asked for this — if a screenshot of a dashboard is dropped while people are discussing metrics, it should appear next to that discussion even if there's a slight timing offset.

**How to apply:** When generating meeting notes from a transcript + images, analyze the image description and visual content against the transcript segments to find the best contextual match, rather than simply placing the image at the chronologically closest point.
