---
name: Memories should be global not project-scoped
description: Save memories to ~/.claude/memory/ (global) not the project-scoped memory path — they apply across all projects
type: feedback
---

Always save memories to `~/.claude/memory/`, not to the project-scoped memory path that the system provides. Feedback, user preferences, and reference memories are almost always cross-project.

**Why:** User pointed out that feedback like "always connect to Agent Manager first" applies to every project, not just the current one. Project-scoped memory would be invisible in other projects.

**How to apply:** Default to global memory. Only use project-scoped memory if the information is genuinely specific to a single project (rare). Always read the global MEMORY.md index at session start.
