---
name: Autonomous execution preference
description: User wants Claude to ask questions during planning but then execute autonomously without seeking confirmation
type: feedback
---

Ask for clarification during planning stages — ideally consolidate all questions into the planning phase. After planning, unless you genuinely cannot make a reasonable best-guess judgement, execute the full specification without nudging the user for confirmations or validation. "Just get on with it" mindset.

**Why:** The user finds mid-execution check-ins disruptive and wants to trust Claude to complete work end-to-end based on the agreed plan.

**How to apply:** Front-load all ambiguity resolution into project/todo creation. Once execution begins, only stop if truly blocked (missing credentials, contradictory requirements, external dependency failures). For judgement calls, pick the most reasonable option and note the decision in the memory log.
