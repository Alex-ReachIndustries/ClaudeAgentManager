# Global Memory Index

## Feedback
- [feedback_autonomous_execution.md](feedback_autonomous_execution.md) — Execute autonomously after planning; no mid-work confirmations
- [feedback_session_protocol.md](feedback_session_protocol.md) — /session-init and /agent-checkin skills MUST be invoked; never skip the mandatory protocol
- [feedback_global_memory.md](feedback_global_memory.md) — Save memories to ~/.claude/memory/ (global), not project-scoped paths
- [feedback_update_tone.md](feedback_update_tone.md) — Agent manager updates should sound natural and conversational, not like machine log entries
- [feedback_reflect_answers.md](feedback_reflect_answers.md) — Always post answers/responses to the agent manager too — user may be reading from the dashboard
- [feedback_poll_delay_autorestart.md](feedback_poll_delay_autorestart.md) — When poll delay is set, schedule a cron to auto-restart polling at expiry — never just stop
- [feedback_always_send_projects_todos.md](feedback_always_send_projects_todos.md) — Every agent manager update must include full projects and todos state, not just when they change
- [feedback_atomic_updates.md](feedback_atomic_updates.md) — Post agent-checkin after EACH todo completion, not in bulk — user monitors dashboard in real-time
- [feedback_workspace_field.md](feedback_workspace_field.md) — Every agent manager update must include workspace field (root folder name)
- [feedback_live_play_by_play.md](feedback_live_play_by_play.md) — Post brief text update before each step for live dashboard play-by-play
- [feedback_mechanical_progress.md](feedback_mechanical_progress.md) — Progress = Math.round((completed / total) * 100), never estimate
- [feedback_auto_commit_check.md](feedback_auto_commit_check.md) — Stop and commit after editing 3+ files
- [feedback_image_matching.md](feedback_image_matching.md) — Place images in meeting notes by content relevance, not just timestamp
- [feedback_speaker_naming.md](feedback_speaker_naming.md) — After transcription, summarize speakers and ask user to assign names before generating PDF

## Reference
- [reference_adb_device.md](reference_adb_device.md) — Android device ADB-over-TCP address: 100.102.68.127:42845

## User
- [user_alex.md](user_alex.md) — User's name is Alex; always the local mic speaker in meetings
- [user_devices.md](user_devices.md) — Pixel 9 Pro XL phone + Pixel Watch 2, both on Tailscale

## Projects
- [project_meeting_transcription.md](project_meeting_transcription.md) — Local audio transcription pipeline in MeetingNotes workspace
