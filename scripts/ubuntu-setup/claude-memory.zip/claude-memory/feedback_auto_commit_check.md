---
name: Auto-commit after 3+ file edits
description: If 3+ files have been edited without committing, stop and commit before continuing
type: feedback
---

If you've edited 3+ files without committing, stop and commit before continuing. Post a reminder to yourself via the agent manager if you catch this.

**Why:** Prevents large uncommitted changesets that are harder to review and riskier to lose. Small, frequent commits are preferred.

**How to apply:** After each file edit, mentally count how many files have been changed since the last commit. If the count reaches 3, pause implementation and commit what you have before proceeding.
