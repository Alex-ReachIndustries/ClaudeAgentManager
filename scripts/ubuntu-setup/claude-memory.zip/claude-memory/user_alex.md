---
name: User Identity - Alex
description: The user's name is Alex and they are always the local speaker in meeting recordings
type: user
---

The user's name is Alex. In meeting transcriptions, Alex is always the speaker on the local microphone — the other speakers come from system audio (calls, YouTube, etc.). Always label Alex's segments with their name, not SPEAKER_XX.
