---
name: user_devices
description: User's mobile devices — Pixel 9 Pro XL (phone) and Pixel Watch 2 (watch), both on Tailscale
type: user
---

- Phone: Pixel 9 Pro XL (model: komodo), ADB serial 48141FDAS004ZE, Tailscale IP 100.102.68.127
- Watch: Pixel Watch 2 (Wear OS) — connected to phone, receives mirrored notifications with RemoteInput reply
- ADB is accessible wirelessly via local network (already paired)
