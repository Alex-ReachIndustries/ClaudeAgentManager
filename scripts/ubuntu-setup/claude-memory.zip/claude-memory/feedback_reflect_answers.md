---
name: Always reflect answers in agent manager
description: When answering a user question, the answer must also be posted to the agent manager — the user may be reading from the dashboard, not the chat
type: feedback
---

When the user asks a question (via the chat OR via an agent manager message) and you provide an answer, that answer MUST also be reflected in an agent manager update. The user may be monitoring from the dashboard rather than reading the Claude session directly.

**Why:** User asked a question via agent manager, Claude answered in the chat but posted nothing back to the dashboard. From the dashboard it looked like the message was processed but no response came back.

**How to apply:** After providing any substantive response to the user — whether it's an answer, analysis, recommendation, or status update — always post it to the agent manager too. The `content` field should contain the key points of the answer. Don't just post "answered the question" — post the actual answer (condensed if needed).
