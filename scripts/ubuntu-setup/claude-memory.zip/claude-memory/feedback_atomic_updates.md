---
name: Atomic agent manager updates
description: Post agent-checkin after EACH todo completion, not in bulk — user monitors dashboard in real-time
type: feedback
---

Post `/agent-checkin` immediately after every `TodoWrite` status change — one todo at a time, one update at a time. Never batch multiple todo completions into a single agent manager update.

**Why:** The user monitors progress from the dashboard in real-time. Bulk updates at the end of a task make the dashboard stale and defeat the purpose of the live tracking system. The user specifically called this out as a consistency problem.

**How to apply:** After marking any todo as `completed` or `in_progress` in TodoWrite, the very next action must be a `/agent-checkin` POST with the updated todos array. Do not start the next piece of work until the update is posted. Same applies to memory log entries — write them incrementally, not as one big entry at the end.
