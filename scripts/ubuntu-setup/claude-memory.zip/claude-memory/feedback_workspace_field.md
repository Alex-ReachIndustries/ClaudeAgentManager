---
name: Include workspace field in agent manager updates
description: Every agent manager checkin POST must include a workspace field with the root folder name of the current working directory
type: feedback
---

Every agent manager update must include `"workspace": "<root_folder_name>"` in the POST body. The value is the root folder name of the current working directory (e.g., "LiquidTransfers", not the full path).

**Why:** The dashboard uses this field to show which workspace/project directory the agent is operating in. Without it, the dashboard can't display workspace context.

**How to apply:** Add `"workspace": "<folder_name>"` to every `/agent-checkin` POST alongside projects and todos. Derive the value from the last component of the current working directory path.
