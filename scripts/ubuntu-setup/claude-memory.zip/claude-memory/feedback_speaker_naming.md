---
name: Speaker Naming Before PDF
description: After transcription, summarize what each speaker said and ask user to assign real names before generating the PDF
type: feedback
---

After transcription completes, do NOT immediately generate the PDF. Instead:

1. Show a summary of what each SPEAKER_XX said (key quotes/topics)
2. Ask the user to assign real names to each speaker
3. Only then generate the meeting data JSON and PDF with the real names

**Why:** SPEAKER_00/01/02 labels are meaningless in a published document. The user knows who was in the meeting and can identify speakers from the summary of what they said.

**How to apply:** Every time a meeting recording is transcribed, present the speaker summary and wait for name assignments before proceeding to PDF generation.
