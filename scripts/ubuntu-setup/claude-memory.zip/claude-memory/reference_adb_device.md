---
name: ADB Device Connection
description: Android device ADB-over-TCP connection details for Alex's phone
type: reference
---

Android device ADB-over-TCP address: `100.102.68.127:42845`

Connect with: `adb connect 100.102.68.127:42845`
