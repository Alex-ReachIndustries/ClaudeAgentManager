---
name: Poll delay must auto-restart via scheduled cron
description: When polling is paused by a delay, always schedule a one-shot cron to restart polling at the delay expiry time — never just stop and wait
type: feedback
---

When a poll delay is received from the agent manager, don't just cancel the cron and stop. Schedule a one-shot cron at the `poll_delay_until` time to automatically restart regular polling. The user should not have to manually restart polling after a delay expires.

**Why:** User set a 1-hour delay to test the feature. Claude cancelled polling but didn't schedule a restart, leaving the agent disconnected with 8 unread messages piling up.

**How to apply:** On receiving `poll_delay_until`:
1. Cancel current polling cron
2. Schedule a one-shot cron at the delay time: the cron prompt should restart regular 1-minute polling
3. Save the delay to `~/.claude/poll-delays.json`

This is a global rule — applies to all projects and sessions.
