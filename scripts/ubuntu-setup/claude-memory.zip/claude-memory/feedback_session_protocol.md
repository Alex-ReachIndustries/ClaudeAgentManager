---
name: Session protocol must be followed without exception
description: CLAUDE.md mandatory protocol section + /session-init and /agent-checkin skills exist specifically because Claude kept forgetting parts of the agent manager / memory / polling protocol
type: feedback
---

The user had to repeatedly correct Claude for missing parts of the session protocol:
- Forgot to connect to Agent Manager before responding to first message
- Forgot to send agent manager updates alongside memory log updates
- Forgot to start idle polling after responding

These failures led to the creation of:
1. `/session-init` skill — handles all one-time session startup tasks
2. `/agent-checkin` skill — handles per-message agent manager updates
3. A **MANDATORY SESSION PROTOCOL** section at the very top of CLAUDE.md

**Why:** The user should NEVER have to remind Claude about these obligations. They are the foundation of how this user works.

**How to apply:** On every session start, the very first thing you read in CLAUDE.md is the mandatory protocol. Follow it literally. Invoke the skills. Don't rationalize skipping them ("it's just a quick question" — doesn't matter). If you catch yourself about to respond without having run the protocol, stop and run it first.
